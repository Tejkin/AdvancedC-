﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Thomas_Chen_Task_Manager
{
    public class Task : IComparable<Task>
    {
        public Guid ID { get; private set; } // A GUID that uniquely identifies the task
        public string Description { get; set; }
        public string Notes { get; set; }
        public bool IsCompleted { get; set; }
        public DateTime? DueDate { get; set; } //DateTime storable as a nullable type

        public bool IsOverdue
        {
            get
            {
                if (DueDate.HasValue)
                {
                    return DateTime.Today > DueDate.Value;
                }
                return false;
            }
        }

        // Static list to store all tasks
        public static List<Task> allTasks = new List<Task>();

        // Static index list to store all tasks sorted by description
        public static List<Task> allTasksByDescription = new List<Task>();

        public Task(string description, string notes = "", DateTime? dueDate = null)
        {
            ID = Guid.NewGuid();
            Description = description;
            Notes = notes;
            IsCompleted = false;
            DueDate = dueDate;
        }

        public void SetID (Guid id)
        {
            ID = id;
        }

        //add a new task to the static list
        public static void AddTask(Task task)
        {
            allTasks.Add(task);

            int index = allTasksByDescription.BinarySearch(task, new TaskDescriptionComparer());
            if (index < 0) index = ~index;
            allTasksByDescription.Insert(index, task);
        }

        // remove a task from the static list, given its ID
        public static void RemoveTask(Guid taskID)
        {
            Task taskToRemove = allTasks.Find(task => task.ID == taskID);

            allTasks.Remove(taskToRemove);
            allTasksByDescription.Remove(taskToRemove);
        }

        public int CompareTo(Task other)
        {
            if (this.DueDate != null && other.DueDate != null && DueDate.Value.CompareTo(other.DueDate.Value) != 0)
            {
                return this.DueDate.Value.CompareTo(other.DueDate.Value);
            }
            else if (this.DueDate != null && other.DueDate == null)
            {
                return 1;
            }
            else if (this.DueDate == null && other.DueDate != null)
            {
                return -1;
            }
            else if (this.DueDate == null && other.DueDate == null)
            {
                return 0;
            }
            // If both task has the same completion date, then sort by description
            else if (this.DueDate.Value == other.DueDate.Value)
            {
                return this.Description.CompareTo(other.Description);
            }
            return 0;

        }

        // Compare by name with Arbitrary searches
        public static int CompareTasksByDescription(Task targetTask, Task searchTask)
        {
            return targetTask.Description.CompareTo(searchTask.Description);
        }

    }

}
